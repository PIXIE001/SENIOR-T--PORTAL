# SAG Attendance Connected
Non-Firebase connected version using Vercel + Neon PostgreSQL.

Deploy repository to Vercel and add:
DATABASE_URL = Neon connection string
APP_SECRET = long random secret

Demo accounts:
teacher / teacher123
admin / admin123
principal / principal123

Change demo passwords before real use. Browser GPS requires HTTPS and user permission.
